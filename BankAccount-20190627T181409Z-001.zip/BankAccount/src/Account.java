import java.util.Date;
import java.util.Scanner;

public abstract class Account {
	
Scanner sc=new Scanner(System.in);

static int AcctNo=100;
public String name;
public int balance;
public String address;
public Date date;


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}


public static int getAcctNo() {
	return AcctNo;
}
public static void setAcctNo(int acctNo) {
	AcctNo = acctNo;
}



public Account() {
	AcctNo++;
	
}



public Account(String name, int balance, String address, Date date) {
	super();
	AcctNo++;
	this.name = name;
	this.balance = balance;
	this.address = address;
	this.date = date;
}



public void openAccount()
{
	
	
	System.out.println("Enter Name:");
	this.name=sc.next();
	System.out.println("Enter Balance:");
	this.balance=sc.nextInt();
	System.out.println("Enter Address:");
	this.address=sc.next();
	this.date=new Date();
	System.out.println("Account created..");
}


public void  display()
{
	System.out.println("Account Number:"+this.AcctNo);
	System.out.println("Name:"+this.name);
	System.out.println("Balance:"+this.balance);
	System.out.println("Address:"+this.address);
	System.out.println("Date:"+this.date);
}

 public abstract void withdraw();
 public abstract void deposit();
 
 public void closeAcc()
 {
	 this.name=null;
	 this.balance=0;
	this.address=null;
	this.date=null;
			 
	 
 }

}
