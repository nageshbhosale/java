import java.util.Scanner;

public class SavingAccount extends Account{

	public void deposit()
	{
		int amount;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter amount to be deposited:");
		amount=sc.nextInt();
		this.balance=this.balance+amount;
		System.out.println("Total balance in an account::"+this.balance);

	}
	
	public void withdraw()
	{
		int amount;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter amount to be withdraw:");
		amount=sc.nextInt();
		
		if(amount>balance)
		{
			System.out.println("Insufficient balance...");
		}
		else
		{
			
		this.balance=this.balance-amount;
		System.out.println("Total balance in an account::"+this.balance);
		
		}

	}
	public void display()
	{
		super.display();
	}
	
}
