import java.util.Scanner;

public class MainApp {
	
	static int count=0;
	
	public static void main(String[] args) 
	{
	
		
		Scanner sc=new Scanner(System.in);
		Account[] acc=new Account[10];
		//Account acc1=new Account();
		String wish;
		do
		{
			System.out.println("Choose Option: 1.Open Account. \n 2.Display Account Details. \n 3.Deposit \n 4.Withdraw. \n 5.Close Account  \n 6.Exit. \n 7.Calculate Interest");
			int ch=sc.nextInt();
			
			switch(ch)
			{
				case 1:
					System.out.println("Select Account type:1.Saving Account. \n 2.Current Account.");
					int ch1=sc.nextInt();
					switch(ch1)
					{
						case 1: 
							acc[count]=new SavingAccount();
							acc[count].openAccount();
							
							acc[count].display();
							count++;
							break;
							
							
						case 2:
							acc[count]=new CurrentAccount();
							acc[count].openAccount();
							count++;
							break;

					}
					break;
				case 2:
					
						System.out.println("Enter account number:");
						int num=sc.nextInt();
						
						for(int i=0;i<=count-1;i++)
						{
							
							if(num==acc[i].getAcctNo())
							{
								
								acc[i].display();
							}
							
						}
						
					
					break;
					
				case 3:
					System.out.println("Enter account number:");
					int num1=sc.nextInt();
					
					for(int i=0;i<=count-1;i++)
					{
						
						if(num1==acc[i].getAcctNo())
						{
							
							acc[i].deposit();
							
						}
						
					}
					
					break;
					
				case 4: 
					System.out.println("Enter account number:");
					int num11=sc.nextInt();
					
					for(int i=0;i<=count-1;i++)
					{
						
						if(num11==acc[i].getAcctNo())
						{
							
							acc[i].withdraw();
							
						}
						
					}
					
					break;
					
				case 5:
					System.out.println("Enter account number:");
					int num111=sc.nextInt();
					boolean flag=false;
					
					for(int i=0;i<=count-1;i++)
					{
						
						if(num111==acc[i].getAcctNo())
						{
							
							
							//acc[i].closeAcc();
							acc[i]=null;
							System.out.println("your account has been closed successfully...");
							flag=true;
							break;
							
						}
						
					}
					
					if(flag==false)
					{
						System.out.println("Invalid account number...");
					}
					
					break;
					
				case 7: 
					System.out.println("Enter account number:");
					int num1111=sc.nextInt();
					
					for(int i=0;i<=count-1;i++)
					{
						
						if(num1111==acc[i].getAcctNo())
						{
							int r=10;
							System.out.println("Enter no. of years:");
							int n=sc.nextInt();
							int Interest= (acc[i].getBalance()*r*n)/100;
							System.out.println("Calculated Interest is::"+Interest);
						
						}
						
					}
				break;
					
					
					
			}
			System.out.println("Do you want to continue...");
			wish=sc.next();
		}while(wish.equals("y")||wish.equals("Y"));
			
		
		
	}

}
