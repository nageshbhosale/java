package Deseri;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;



public class main {

	public static void main(String[] args) 
	{
		
		try{
			
		StudentInfo[] s1=new StudentInfo[5];
		
		
		/*s1[0]=new StudentInfo("abc",1,"12345");
		s1[1]=new StudentInfo("abc",2,"12345");
		s1[2]=new StudentInfo("abc",3,"12345");*/
		
		for(int i=0;i<2;i++)
		{
		
			s1[i]=new StudentInfo();
			s1[i].accept();
		}
		
		FileOutputStream fos=new FileOutputStream("p111.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(s1);
		oos.close();
		fos.close();
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		StudentInfo s1[]=null;
		
		try{
			FileInputStream fis=new FileInputStream("p111.ser");
			ObjectInputStream ois=new ObjectInputStream(fis);
			s1=(StudentInfo[])ois.readObject();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		for(int i=0;i<2;i++)
		{
		
		/*System.out.println(s1[i].name);
		System.out.println(s1[i].rid);
		System.out.println(s1[i].contact);
*/		
			
			s1[i].display();
			
		}
	}
	
}


